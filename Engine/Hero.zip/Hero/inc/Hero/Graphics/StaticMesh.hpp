#pragma once

namespace Hero
{

class StaticMesh
{

};

}