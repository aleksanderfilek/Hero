#pragma once

namespace Hero
{

struct SphereCollider
{
  float Radius;
};

}