#pragma once

namespace Hero
{

struct CapsuleCollider
{
  float Radius;
  float Length;
};

}