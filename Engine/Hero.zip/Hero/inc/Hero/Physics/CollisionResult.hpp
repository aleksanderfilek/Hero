#pragma once

namespace Hero
{

struct CollisionResult
{
  bool Hit = false;
};

}