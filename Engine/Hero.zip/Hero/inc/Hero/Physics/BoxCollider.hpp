#pragma once

#include"../Core/Math.hpp"


namespace Hero
{

struct BoxCollider
{
  Hero::Float3 PointA;
  Hero::Float3 PointB;
};

}