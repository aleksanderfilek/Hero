#pragma once

namespace Hero
{
    class Music
    {

    };
} // namespace Hero
