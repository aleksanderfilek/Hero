namespace Hero
{
namespace System
{

class Audio
{

};
  
}
}