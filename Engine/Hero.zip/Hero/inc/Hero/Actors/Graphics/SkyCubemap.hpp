#pragma once

#include "../../Systems/ActorScene/Actor.hpp"
#include "../../Core/Sid.hpp"
#include "../../Components/Transform.hpp"

namespace Hero
{

class SkyCubemap : public Actor
{
private:
  class Cubemap* cubemap;
  class Material* material;
  TransformComponent transform;
  
public:
  HERO SkyCubemap(const Sid& NewId);

  HERO void Start() override;
  HERO void Update() override;
  HERO void End() override;

  HERO void SetMaterial(class Material* Material);
  HERO void SetCubemap(class Cubemap* Cubemap);
};

}