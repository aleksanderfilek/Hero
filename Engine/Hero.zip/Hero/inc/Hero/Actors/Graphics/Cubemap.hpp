#pragma once

#include "../../Systems/ActorScene/Actor.hpp"
#include "../../Core/Sid.hpp"
#include "../../Components/Transform.hpp"

namespace Hero
{

class Cubemap : public Actor
{
private:
  class Cubemap* cubemap;
  class Material* material;
  TransformComponent transform;
  
public:
  Cubemap(const Sid& NewId);

  virtual void Start() override;
  virtual void Update() override;
  virtual void End() override;

  void SetMaterial(class Material* Material);
  void SetCubemap(class Cubemap* Cubemap);
};

}