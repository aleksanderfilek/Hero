#pragma once

namespace Hero
{

class SkeletalMesh
{

};

}