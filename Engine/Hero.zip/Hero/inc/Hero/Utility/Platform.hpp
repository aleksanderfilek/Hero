#pragma once

#include<string>

namespace Hero
{

std::string GetCurrentDirectory();

}