#pragma once

namespace Hero
{

HERO void randomSetSeed(int seed);
HERO int randomGetInt(int min, int max);
HERO float randomGetFloat(float min, float max);

}