#pragma once

namespace Hero
{

class IScene
{

};

}