#pragma once

namespace Hero
{
namespace UI
{

class Button
{

};

}
}