#pragma once

namespace Hero
{
namespace UI
{

enum class Alligment
{
  LEFT_TOP,
  TOP,
  RIGHT_TOP,
  LEFT,
  CENTER,
  RIGHT,
  LEFT_BOTTOM,
  BOTTOM,
  RIGHT_BOTTOM,
};

}
}