#pragma once
#define GLEW_STATIC
#include"glew.h"
#include<GL/glu.h>
#include<GL/gl.h>