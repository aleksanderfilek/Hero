#pragma once

#include"../Hero/Systems/ActorScene/ActorScene.hpp"
#include"../Hero/Systems/Window.hpp"
#include"../Hero/Graphics/Shader.hpp"
#include"../Hero/Graphics/Mesh.hpp"

class Game : public Hero::ActorScene
{
private:
  Hero::System::Window* window;

public:
  void Start() override;
  void Update() override;
  void End() override;
};