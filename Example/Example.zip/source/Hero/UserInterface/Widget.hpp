#pragma once

#include"../Core/Math.hpp"
#include"IGroup.hpp"

#include<vector>

namespace Hero
{
namespace UI
{

class IElement;

class Widget : public IGroup
{
  public:
  HERO Widget();
};

}
}